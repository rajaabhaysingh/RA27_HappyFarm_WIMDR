import { createStore } from "redux";

const reducer = () => {};

const store = createStore(reducer);

export default store;

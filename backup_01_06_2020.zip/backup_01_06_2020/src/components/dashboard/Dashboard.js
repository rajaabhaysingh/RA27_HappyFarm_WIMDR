import React from "react";
import { Sidebar } from "./Sidebar";

export const Dashboard = () => {
  return (
    <div>
      <Sidebar />
    </div>
  );
};

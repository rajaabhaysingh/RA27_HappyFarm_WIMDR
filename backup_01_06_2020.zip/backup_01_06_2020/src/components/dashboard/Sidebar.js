import React from "react";
import {
  PlusOutlined,
  HistoryOutlined,
  UserOutlined,
  ShoppingCartOutlined,
  BankOutlined,
  QuestionCircleOutlined,
  PoweroffOutlined,
  PhoneOutlined,
} from "@ant-design/icons";
// import { FaUserCircle } from "react-icons/fa";

export const Sidebar = () => {
  return (
    <div className="sidebar" data-testid="sidebar">
      <div className="sidebar_profile_info" data-testid="sidebar_profile_info">
        <div className="sidebar_profile_image">
          <img src="" alt="user_image" />
        </div>
        <div className="sidebar_profile_image_change_icon">
          <img src="" alt="camera_icon" />
        </div>
        <div className="sidebar_username">Hello, Mark Zuke</div>
        <div className="sidebar_plan">
          <div className="sidebar_plan_text">Plan:</div>
          <div className="sidebar_plan_value">Free</div>
        </div>
        <div className="sidebar_contact">
          <PhoneOutlined rotate={90} /> +91 8209898775
        </div>
      </div>
      <div
        className="sell_new_product_button_group"
        data-testid="sell_new_product_button_group"
      >
        <button className="sell_new_product_button">
          <span className="sell_new_product_text">Sell new product</span>
          <span className="sell_new_product_icon">
            <PlusOutlined />
          </span>
        </button>
      </div>
      <div className="menu_text_display">MENU</div>
      <div className="sidebar_menu" data-testid="sidebar_menu">
        <ul className="sidebar_menu_list">
          <li className="sidebar_menu_item">
            <span className="sidebar_menu_profile_icon">
              <UserOutlined />
            </span>
            <span className="sidebar_menu_profile">Profile</span>
          </li>
          <li className="sidebar_menu_item">
            <span className="sidebar_menu_sell_history_icon">
              <HistoryOutlined />
            </span>
            <span className="sidebar_menu_sell_history">Sell history</span>
          </li>
          <li className="sidebar_menu_item">
            <span className="sidebar_menu_purchase_history_icon">
              <ShoppingCartOutlined />
            </span>
            <span className="sidebar_menu_purchase_history">
              Purchase history
            </span>
          </li>
          <li className="sidebar_menu_item">
            <span className="sidebar_menu_transactions_icon">
              <BankOutlined />
            </span>
            <span className="sidebar_menu_transactions">Transactions</span>
          </li>
          <li className="sidebar_menu_item">
            <span className="sidebar_menu_hekpdesk_icon_icon">
              <QuestionCircleOutlined />
            </span>
            <span className="sidebar_menu_hekpdesk">Helpdesk</span>
          </li>
        </ul>
      </div>
      <div className="sidebar_logout" data-testid="sidebar_logout">
        <span>
          <PoweroffOutlined />
        </span>
        <span>Logout</span>
      </div>
    </div>
  );
};

import React from "react";

function Premium() {
  return (
    <div>
      <div>This is Premium</div>
    </div>
  );
}

export default Premium;

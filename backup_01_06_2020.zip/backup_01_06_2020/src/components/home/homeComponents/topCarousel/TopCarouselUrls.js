const topCarouselUrls = [
  {
    name: "Photo 1",
    imgUrl:
      "https://static.vecteezy.com/system/resources/thumbnails/000/381/503/small/ZZZZZ2344.jpg",
  },
  {
    name: "Photo 2",
    imgUrl:
      "https://image.freepik.com/free-vector/blue-technology-glowing-lines-background_1017-17493.jpg",
  },
  {
    name: "Photo 3",
    imgUrl:
      "https://i.pinimg.com/originals/16/db/49/16db4962e4fc84c0b5963c95c6192385.jpg",
  },
  {
    name: "Photo 4",
    imgUrl:
      "https://img.freepik.com/free-vector/blue-banner-design-with-wave-wire-mesh_1017-14296.jpg?size=626&ext=jpg",
  },
  {
    name: "Photo 5",
    imgUrl: "https://www.gazetatema.net/wp-content/uploads/2020/03/1.jpg",
  },
];

export default topCarouselUrls;

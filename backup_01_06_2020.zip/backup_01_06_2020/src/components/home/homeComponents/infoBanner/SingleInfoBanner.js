import React from "react";
import "./SingleInfoBanner.css";

function SingleInfoBanner() {
  return (
    <div className="single_info_banner">
      <div className="single_info_details"></div>
    </div>
  );
}

export default SingleInfoBanner;

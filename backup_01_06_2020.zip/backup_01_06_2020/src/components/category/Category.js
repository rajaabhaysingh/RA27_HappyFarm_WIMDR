import React from "react";

const Category = () => {
  return (
    <div>
      <div>This is Category</div>
    </div>
  );
};

export default Category;

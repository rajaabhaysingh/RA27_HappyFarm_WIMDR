import React from "react";
import "./SignInUp.css";

import { NavLink } from "react-router-dom";

function SignInUp() {
  return (
    <div className="sign_in_main_div">
      <div className="sign_in_inner_div">
        <div className="sign_in_graphics">
          <div className="sign_in_graphics_text">
            <div className="sign_in_graphics_heading">Login</div>
            <div className="sign_in_graphics_desc">
              Get access to your Orders, Wishlist, Recommendations and much
              more.
            </div>
          </div>
          <div className="sign_in_graphics_image"></div>
        </div>
        <div className="sign_in_form_container">
          <form className="sign_in_form">
            <input required className="sign_in_email_mob" type="text" />
            <input required className="sign_in_pwd" type="password" />
            <input className="sign_in_login_btn" type="submit" value="LOGIN" />
            <NavLink className="sign_in_forgot_pwd" to="/">
              Forgot password ?
            </NavLink>
            <div className="sign_in_using_container"></div>
            <NavLink className="sign_in_sign_up" to="/">
              New to happyfarm? Sign up now.
            </NavLink>
          </form>
        </div>
      </div>
    </div>
  );
}

export default SignInUp;

import React from "react";
import "./Contact.css";

function Contact() {
  return (
    <div className="contact_main_div">
      <div>This is Contact</div>
    </div>
  );
}

export default Contact;

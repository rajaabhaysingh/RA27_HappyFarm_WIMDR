import React, { useState } from "react";
import "./SignedOutLinks.css";
import { NavLink } from "react-router-dom";
import { LoginOutlined } from "@ant-design/icons";
import UserPlaceholder from "../../../res/header/user_placeholder.svg";

import Popup from "reactjs-popup";
import SignInUp from "../../auth/SignInUp";

function SignedOutLinks() {
  // -------Toggle user btn click F(n)----------------
  let [isSignedOutLinkOpen, setIsSignedOutLinkOpen] = useState(false);

  let userBtnClickHandler = () => {
    if (!isSignedOutLinkOpen) {
      setIsSignedOutLinkOpen(true);
    }
  };

  let signedOutListClass = "signed_out_list--hidden";

  if (isSignedOutLinkOpen) {
    signedOutListClass = "signed_out_list--visible";
  }

  const handleSignedOutListClose = () => {
    setIsSignedOutLinkOpen(false);
  };

  // used (!isCatListOpen) as hack because correct state isn't updated
  // in runtime of following code
  // if (isSignedLinkOpen) {
  //   console.log(isSignedLinkOpen);
  //   const signedInListDiv = document.getElementById("signed_out_list--visible");

  //   if (signedInListDiv) {
  //     window.addEventListener("click", function (e) {
  //       if (!signedInListDiv.contains(e.target)) {
  //         setIsSignedLinkOpen(false);
  //       }
  //     });
  //   }
  // }
  // -----------------------------------------

  return (
    <div className="signed_out_main_div">
      <div
        className="signed_out_profile_btn"
        onClick={userBtnClickHandler}
        onMouseOver={userBtnClickHandler}
      >
        <img
          className="signed_out_profile_image"
          src={UserPlaceholder}
          alt="user-profile"
        />
      </div>
      <div
        className="signed_out_dropdown_component"
        onMouseLeave={handleSignedOutListClose}
      >
        <ul className={signedOutListClass} id="signed_out_list--visible">
          <li className="signed_out_top_arrow_container">
            <div className="signed_out_top_arrow"></div>
          </li>

          <Popup
            trigger={
              <li
                className="signed_out_item"
                // onClick={handleSignedOutListClose}
              >
                <div className="signed_out_sign_in">
                  <div className="signed_out_icon signed_out_sign_in_icon">
                    <LoginOutlined />
                  </div>
                  <div className="signed_out_text signed_out_sign_in_text">
                    Login / Sign-up
                  </div>
                </div>
              </li>
            }
            modal
            closeOnDocumentClick
            lockScroll
            onClose={handleSignedOutListClose}
          >
            <SignInUp />
          </Popup>
        </ul>
      </div>
    </div>
  );
}

export default SignedOutLinks;

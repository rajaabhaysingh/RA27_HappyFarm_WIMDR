import React from "react";
import "./SideDrawer.css";
import {
  ArrowLeftOutlined,
  GlobalOutlined,
  PlusOutlined,
  HomeOutlined,
  AuditOutlined,
  BellOutlined,
  InfoCircleOutlined,
  PhoneOutlined,
  QuestionCircleOutlined,
  StarOutlined,
  PercentageOutlined,
  UserOutlined,
  MessageOutlined,
  AppstoreOutlined,
  AndroidFilled,
  AppleFilled,
} from "@ant-design/icons";

const SideDrawer = (props) => {
  let drawerClasses = ["side_drawer"];

  if (props.showDrawer) {
    drawerClasses = ["side_drawer", "drawer_open"];
  }

  // const closeDrawer = () => {
  //   console.log("closed");
  // };

  // sideDrawer style wrapper
  // const sideDrawerStyle = {
  //   transform: `translateX(${props.translatePercent})`,
  // };

  return (
    // <nav className={drawerClasses}>    ~optional
    <nav
      // style={sideDrawerStyle}
      className={drawerClasses.join(" ")}
      id="side_drawer"
    >
      {/* sidebar header div */}
      <div className="sidebar_header">
        <div className="sidebar_back_button">
          <div className="sidebar_back_icon">
            <ArrowLeftOutlined />
          </div>
          <div className="sidebar_back_text">Logo here</div>
        </div>
        <div className="sidebar_header_spacer"></div>
        <div className="sidebar_change_language">
          <div className="sidebar_change_language_icon">
            <GlobalOutlined />
          </div>
          <div className="sidebar_change_language_text">English</div>
        </div>
      </div>
      {/* sidebar sell with us button */}
      <div className="sidebar_sell_with_us_btn_container">
        <button className="sidebar_sell_with_us_btn">
          Sell with us <PlusOutlined />
        </button>
      </div>
      {/* divider div */}
      {/* <div className="sidebar_divider"></div> */}
      {/* sidebar menu list 1*/}
      <div className="sidebar_menu_list">
        <ul>
          <li className="sidebar_menu_item">
            <div className="sidebar_menu_items_logo">
              <HomeOutlined />
            </div>
            Home
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <AppstoreOutlined />
            </div>
            Categories
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <MessageOutlined />
            </div>
            Messages
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <UserOutlined />
            </div>
            Account
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <PercentageOutlined />
            </div>
            Offers
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <StarOutlined />
            </div>
            Premium
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <QuestionCircleOutlined />
            </div>
            Farmer's Solution
          </li>
        </ul>
      </div>
      {/* divider div */}
      {/* <div className="sidebar_divider"></div> */}
      {/* sidebar menu list 2 */}
      <div className="sidebar_menu_list">
        <ul>
          <li>
            <div className="sidebar_menu_items_logo">
              <PhoneOutlined />
            </div>
            Contact
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <InfoCircleOutlined />
            </div>
            About Us
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <BellOutlined />
            </div>
            Notification
          </li>
          <li>
            <div className="sidebar_menu_items_logo">
              <AuditOutlined />
            </div>
            Legal
          </li>
        </ul>
      </div>
      {/* sidebar body spacer */}
      <div className="sidebar_body_spacer"></div>
      {/* footer div */}
      <div className="footer">
        <button>
          <div className="sidebar_footer_icon_android">
            <AndroidFilled />
          </div>
          <div className="footer_text">Download App</div>
          <div className="sidebar_footer_icon_ios">
            <AppleFilled />
          </div>
        </button>
      </div>
    </nav>
  );
};

export default SideDrawer;

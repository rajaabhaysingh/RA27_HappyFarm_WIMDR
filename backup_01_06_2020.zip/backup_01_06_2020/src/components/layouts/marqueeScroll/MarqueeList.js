const MarqueeList = [
  {
    id: "yyb6y",
    imgUrl:
      "https://pbs.twimg.com/profile_images/448209321562624000/dNzzZNSg_400x400.jpeg",
  },
  {
    id: "crcr4",
    imgUrl:
      "https://etimg.etb2bimg.com/thumb/msid-57449643,imgsize-58373,width-800,height-434,overlay-etbrandequity/whirlpool-introduces-a-brand-new-logo-can-you-spot-the-changes.jpg",
  },
  {
    id: "77jrc4",
    imgUrl: "https://www.oriontravels.com/front/images/logo.jpg",
  },
  {
    id: "bufwfkl",
    imgUrl:
      "https://english.cdn.zeenews.com/sites/default/files/2019/11/05/828486-facebook.jpg",
  },
  {
    id: "8y8",
    imgUrl:
      "https://cart208spring14.files.wordpress.com/2014/03/fed-ex-logo.jpg",
  },
  {
    id: "49yc83",
    imgUrl:
      "https://www.logoarena.com/contestimages/public_new/5739/6425_1427951681_unitedroofing.png",
  },
  {
    id: "y784t3b78",
    imgUrl:
      "https://s3.paultan.org/image/2020/03/2020-Nissan-Z-trademark-630x355.jpg",
  },
  {
    id: "4bt67",
    imgUrl:
      "https://www.logo-designer.co/wp-content/uploads/2019/02/2019-vivo-new-logo-design.png",
  },
];

export default MarqueeList;

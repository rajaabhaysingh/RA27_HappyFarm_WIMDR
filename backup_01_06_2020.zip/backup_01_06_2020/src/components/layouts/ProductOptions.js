const ProductOptions = `
Apple
Banana
Guava
Rice
Tomato
Cucumber
Curry
Cumin
Carrot
Cabbage
Cauli Flower`.split("\n");

export default ProductOptions;

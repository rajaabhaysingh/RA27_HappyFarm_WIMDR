import React from "react";
import "./BreadCrumbs.css";

function BreadCrumbs() {
  return (
    <div className="breadcrumbs_main_div">
      <div className="breadcrumbs_inner_main_div"></div>
    </div>
  );
}

export default BreadCrumbs;

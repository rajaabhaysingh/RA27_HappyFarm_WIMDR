const FooterDetails = {
  contactDetails: ["+91 8002023337", "roozgaar@mail.com"],
  socialDetails: [
    { name: "Facebook", link: "#" },
    { name: "Instagram", link: "#" },
    { name: "Twitter", link: "#" },
    { name: "LinkedIn", link: "#" },
    { name: "Youtube", link: "#" },
  ],
  services: [
    { name: "Contact us", link: "#" },
    { name: "Ordering & Payment", link: "#" },
    { name: "Shipping", link: "#" },
    { name: "Returns", link: "#" },
    { name: "FAQs", link: "#" },
  ],
  info: [
    { name: "About us", link: "#" },
    { name: "Sell with us", link: "#" },
    { name: "Privacy Policy", link: "#" },
    { name: "Terms & Conditions", link: "#" },
    { name: "Press Enquiries", link: "#" },
  ],
  newsletter:
    "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia",
};

export default FooterDetails;

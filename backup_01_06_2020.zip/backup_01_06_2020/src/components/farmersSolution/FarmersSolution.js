import React from "react";

export const FarmersSolution = () => {
  return (
    <div>
      <div>This is Farmer's Solution</div>
    </div>
  );
};

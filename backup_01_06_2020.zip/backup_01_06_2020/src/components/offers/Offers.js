import React from "react";

function Offers() {
  return (
    <div>
      <div>This is Offers</div>
    </div>
  );
}

export default Offers;
